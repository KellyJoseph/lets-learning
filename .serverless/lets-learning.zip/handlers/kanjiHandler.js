module.exports = {
  getAllKanji: () => {
    return {
      kanji: "水",
      kunyomi: "みず",
      meaning: "water"
    };
  }
};
